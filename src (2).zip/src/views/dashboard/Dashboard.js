import React from 'react'
import classNames from 'classnames'


import WidgetsBrand from '../widgets/WidgetsBrand'
import WidgetsDropdown from '../widgets/WidgetsDropdown'


const Dashboard = () => {
  

  

  return (
    <>
      {/* <WidgetsDropdown className="mb-4" /> */}
      <h1>Dashboard</h1>
   
    </>
  )
}

export default Dashboard
