import ScheduledClasses from "./ScheduledClasses/ScheduledClasses";
import WidgetsBrand from "../widgets/WidgetsBrand";
import BasicInformation from "./Form/BasicInformation/BasicInformation";
function Events(){
    return(
        <div className="events-body">
        <ScheduledClasses className="mb-4" withCharts/>
        {/* <WidgetsBrand className="mb-4" withCharts /> */}
        {/* <BasicInformation className="mb-4" withCharts/> */}
        </div>

    );
}
export default Events;